ZipRecruiter.JobAlertsAPI.dll

Simple integration library for ZipRecruiter Job Alert Partners.
Requires .Net 4.0 or later, and Microsoft.CSharp.dll must be referenced

For support and bug reports email max@ziprecruiter.com, CC alertsteam@ziprecruiter.com

For examples on how to use the code, please view the included Examples.cs file.

Code Attribution:

In compliance with StackOverflow's License (cc-wiki with attribution required), it should be noted that
this library contains code for handling Multi-part form submissions found at:

http://stackoverflow.com/questions/219827/multipart-forms-from-c-sharp-client
Author: Brian Grinstead